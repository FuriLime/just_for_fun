#SXD20|20011|50626|50612|2015.09.23 15:14:37|eventfellows|0|18|55|
#TA activations`2`16384|blog_categories`0`16384|blog_comments`0`16384|blogs`2`16384|eventcategories`0`16384|events`3`16384|migrations`13`16384|password_resets`0`16384|persistences`24`16384|reminders`0`16384|role_users`2`16384|roles`2`16384|taggable_taggables`3`16384|taggable_tags`2`16384|throttle`0`16384|usergroups`0`16384|users`2`16384|users-`0`16384
#EOH

#	TC`activations`utf8_unicode_ci	;
CREATE TABLE `activations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`activations`utf8_unicode_ci	;
INSERT INTO `activations` VALUES 
(1,1,'M3MfDJFmya0J6mWjANvBzKQg8ossh21F',1,'2015-09-10 09:34:50','2015-09-10 09:34:50','2015-09-10 09:34:50'),
(2,2,'k3uy1gNaCTNgvidVoPueIe6SZzSy7EgP',1,'2015-09-10 09:51:21','2015-09-10 09:51:21','2015-09-10 09:51:21'),
(3,3,'4CGjlY4OB6Lssxm4C7CwV7N37Irj28zP',1,'2015-09-15 06:49:46','2015-09-15 06:49:45','2015-09-15 06:49:46')	;
#	TC`blog_categories`utf8_unicode_ci	;
CREATE TABLE `blog_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`blog_comments`utf8_unicode_ci	;
CREATE TABLE `blog_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`blogs`utf8_unicode_ci	;
CREATE TABLE `blogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blog_category_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`blogs`utf8_unicode_ci	;
INSERT INTO `blogs` VALUES 
(1,1,1,'article 1','article 1 description<br>','',3,'2015-09-10 10:17:32','2015-09-11 09:18:57',\N,'article-1'),
(2,1,1,'article2','article 2 description<br>','',1,'2015-09-10 12:16:13','2015-09-22 06:31:05',\N,'article2')	;
#	TC`eventcategories`utf8_unicode_ci	;
CREATE TABLE `eventcategories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`events`utf8_unicode_ci	;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `finish` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`events`utf8_unicode_ci	;
INSERT INTO `events` VALUES 
(1,'Rock-fest 2015',2,'Description of event','Location','http://www.url.com','1.0','2015-09-23 11:01:42','2015-09-23 11:01:42','2015-09-24 10:00:00','2015-09-28 10:00:00',0),
(2,'Rock-fest 2015 - 2',2,'Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event Please describe your event ','here','url','4.5','2015-09-23 11:15:45','2015-09-23 11:15:45','2015-09-24 10:00:00','2015-09-26 10:00:00',1),
(3,'Rock-fest 2015 - 3',3,'desc','loc','url','0.0','2015-09-23 11:34:19','2015-09-23 11:34:19','2015-09-25 09:00:00','2015-09-26 12:30:00',1)	;
#	TC`migrations`utf8_unicode_ci	;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`migrations`utf8_unicode_ci	;
INSERT INTO `migrations` VALUES 
('2014_07_02_230147_migration_cartalyst_sentinel',1),
('2014_10_04_174350_soft_delete_users',1),
('2014_10_12_000000_create_users_table',2),
('2014_10_12_100000_create_password_resets_table',2),
('2014_12_10_011106_add_fields_to_user_table',2),
('2015_08_09_200015_create_blog_module_table',2),
('2015_09_10_092657_add_slug_to_blogs_table',3),
('2015_09_10_092716_create_taggable_table',3),
('2015_09_10_143151_create_books_table',4),
('2015_09_11_062604_create_events_table',5),
('2015_09_11_063730_create_usergroups_table',6),
('2015_09_11_063751_create_eventcategories_table',7),
('2015_09_22_124455_change_event_table',8)	;
#	TC`password_resets`utf8_unicode_ci	;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`persistences`utf8_unicode_ci	;
CREATE TABLE `persistences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `persistences_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`persistences`utf8_unicode_ci	;
INSERT INTO `persistences` VALUES 
(1,1,'OHcfzXLjYLbGPLKuELuf3zbDJi3Bd7WO','2015-09-10 09:40:45','2015-09-10 09:40:45'),
(2,1,'MtzT4apjSn8wSXnlNITgHIR90YeKkooK','2015-09-14 11:52:52','2015-09-14 11:52:52'),
(3,3,'jPwfMkxmSsxOAnwkOML3pFni0qhWV5ZE','2015-09-15 06:49:47','2015-09-15 06:49:47'),
(6,1,'nnfVGaFO2j3cACfumPXjsBKIKgcQA2F3','2015-09-15 13:45:38','2015-09-15 13:45:38'),
(7,1,'1c6cua7sH3o3BKNeue82O7AAmcSkcw23','2015-09-15 13:57:17','2015-09-15 13:57:17'),
(10,1,'1ultIQzV3Kpa0vIpwodlzBp2VqwKMOXy','2015-09-16 09:53:10','2015-09-16 09:53:10'),
(11,1,'Kjwz8oN2l1bBT6hVaIpByPORuHpP0lzK','2015-09-16 09:53:51','2015-09-16 09:53:51'),
(12,1,'WXG3SSTlZPNUjCrGw1j09uiddWNeVd6h','2015-09-16 09:57:46','2015-09-16 09:57:46'),
(13,1,'VnpxqC6uvryQTO7oilweuTpq5hZaxeaR','2015-09-16 09:57:59','2015-09-16 09:57:59'),
(14,1,'o6GPNm1ahlV72mXJ8q6k15yaNCV28njK','2015-09-16 09:59:05','2015-09-16 09:59:05'),
(15,1,'o2c7sB4K4rtz5gR0MzxrXv0jz3NYDYX0','2015-09-16 10:00:48','2015-09-16 10:00:48'),
(16,1,'mN0EZ0ix8KMDSbC3uxL1vgdzOGdZFOlq','2015-09-16 10:06:19','2015-09-16 10:06:19'),
(17,1,'QbEfYqrujDQ5iksQAnMNvl2rE9zCC19R','2015-09-16 10:06:42','2015-09-16 10:06:42'),
(18,1,'8Qu4UxbGApNO37txD7rtQcqgoirZpJsm','2015-09-16 10:09:07','2015-09-16 10:09:07'),
(19,1,'mAskiZbZJJsSSPOmrjOROqV9Wk9Ai4WD','2015-09-16 10:30:02','2015-09-16 10:30:02'),
(21,3,'yIVVmssjOIjPkkTxB9uIb5NeRXuZ7lTZ','2015-09-16 10:32:33','2015-09-16 10:32:33'),
(22,3,'1MIDDtK5LGXIDDx9fn0P208lf1T0ZTdv','2015-09-16 10:46:17','2015-09-16 10:46:17'),
(23,3,'nn5SN2KxdcdRoE4ZFa8PMWdA3XOdkrB3','2015-09-16 10:49:08','2015-09-16 10:49:08'),
(24,3,'x2Zo5Yf78VHVaJlFxYDc7mhzvR1mwCY3','2015-09-16 10:54:47','2015-09-16 10:54:47'),
(25,3,'xfI1CKd6LQkn0ESTqe5iNDpL6g2YCscz','2015-09-16 10:56:01','2015-09-16 10:56:01'),
(26,3,'SEB07flMRQgy6Ct1mWFjh3ndeqp3oB9S','2015-09-16 10:56:29','2015-09-16 10:56:29'),
(27,3,'atzRpc90m85ReePEKCwvx5UIcADeT4xk','2015-09-16 11:20:29','2015-09-16 11:20:29'),
(29,1,'RuBDaxqXuon4PmSv2jQjytFjJAjT9euw','2015-09-22 06:32:08','2015-09-22 06:32:08'),
(30,1,'LhJHulsEslFA4gBJTCqwmyvysdVcdsGr','2015-09-23 07:43:11','2015-09-23 07:43:11')	;
#	TC`reminders`utf8_unicode_ci	;
CREATE TABLE `reminders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`role_users`utf8_unicode_ci	;
CREATE TABLE `role_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`role_users`utf8_unicode_ci	;
INSERT INTO `role_users` VALUES 
(1,1,'2015-09-10 09:34:50','2015-09-10 09:34:50'),
(2,2,'2015-09-10 09:51:21','2015-09-10 09:51:21'),
(3,2,'2015-09-15 06:49:46','2015-09-15 06:49:46')	;
#	TC`roles`utf8_unicode_ci	;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`roles`utf8_unicode_ci	;
INSERT INTO `roles` VALUES 
(1,'admin','Admin','{\"admin\":1}','2015-09-10 09:34:50','2015-09-10 09:34:50'),
(2,'user','User',\N,'2015-09-10 09:34:50','2015-09-10 09:34:50')	;
#	TC`taggable_taggables`utf8_unicode_ci	;
CREATE TABLE `taggable_taggables` (
  `tag_id` int(11) NOT NULL,
  `taggable_id` int(10) unsigned NOT NULL,
  `taggable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `taggable_taggables_taggable_id_index` (`taggable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`taggable_taggables`utf8_unicode_ci	;
INSERT INTO `taggable_taggables` VALUES 
(1,1,'App\\Blog','2015-09-10 12:12:07','2015-09-10 12:12:07'),
(2,1,'App\\Blog','2015-09-10 12:12:07','2015-09-10 12:12:07'),
(2,2,'App\\Blog','2015-09-10 12:16:13','2015-09-10 12:16:13')	;
#	TC`taggable_tags`utf8_unicode_ci	;
CREATE TABLE `taggable_tags` (
  `tag_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `normalized` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`taggable_tags`utf8_unicode_ci	;
INSERT INTO `taggable_tags` VALUES 
(1,'tag1','tag1','2015-09-10 12:12:07','2015-09-10 12:12:07'),
(2,'tag2','tag2','2015-09-10 12:12:07','2015-09-10 12:12:07')	;
#	TC`throttle`utf8_unicode_ci	;
CREATE TABLE `throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `throttle_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`usergroups`utf8_unicode_ci	;
CREATE TABLE `usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TC`users`utf8_unicode_ci	;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `last_login` timestamp NULL DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`users`utf8_unicode_ci	;
INSERT INTO `users` VALUES 
(1,'admin@admin.com','$2y$10$AwjnZV0Y6bkVYRpc3BBte.5cnk1o1bvbJw2u4gQ45kdbxYDZL4O5O',\N,'2015-09-23 10:40:00','John','Doe','2015-09-10 09:34:49','2015-09-23 10:40:00',\N),
(2,'email@mail.com','$2y$10$vKPCM9Jh83MN5tFQFw2PjudgBVosgEezg3QJkeNV/OlSenoymVvMK',\N,\N,'First Name','Last Name','2015-09-10 09:51:21','2015-09-10 09:51:21',\N),
(3,'user@user.com','$2y$10$iW6wz..8hV2XGrvLvDC2Z.FVK1Yl4ThA8TX3QqHrBTZXZV.6hmt1q',\N,'2015-09-16 11:20:29','user','fff','2015-09-15 06:49:45','2015-09-16 11:20:29',\N)	;
#	TC`users-`utf8_unicode_ci	;
CREATE TABLE `users-` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bio` text COLLATE utf8_unicode_ci,
  `gender` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `pic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
